sap.ui.define([
               "sap/ui/core/mvc/Controller"

               ], function (Controller) {
	"use strict";

	return Controller.extend("ns.controller.Main", {

     init : function(){
    	 
    	 
     },
     
     onSubmit : function(){
    	 
    	 alert("Registration Successfull");
     }
	});

});