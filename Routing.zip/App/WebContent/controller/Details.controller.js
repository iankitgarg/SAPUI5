sap.ui.define([ "sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";
	var oMail;
	var oAddress;
	var oContact;
	
	return Controller.extend("ns.controller.Details", {

		init : function() {

		},
		_Validation : function() {

			oMail = this.getView().byId("idAddress").getValue();
			oAddress = this.getView().byId("idContact").getValue();
			oContact = this.getView().byId("idmail").getValue();
			
		},
		onSubmit : function(){
			
			this._CheckValues();
			if (oMail && oAddress && oContact ) {
				alert("Registration Successfull");

			} else {

				alert("Fill All required Fields");
			}
		
		},
		
		onBack : function(){
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Main");
			
		}
	     
	});

});