sap.ui.define([ "sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";
	var oName;
	var oAge;
	var oCity;
	var oGender;
	var oContact;
	return Controller.extend("ns.controller.Main", {

		init : function() {

		},

		_CheckValues : function() {

			oName = this.getView().byId("idName").getValue();
			oAge = this.getView().byId("idAge").getValue();
			oCity = this.getView().byId("idCity").getValue();
			oGender = this.getView().byId("idGender").getValue();
			oContact = this.getView().byId("idContact").getValue();

		},

		onNext : function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("details");
//			this._CheckValues();
//			if (oName && oAge && oCity && oGender && oContact) {
//				alert("Registration Successfull");
//
//			} else {
//
//				alert("Fill All required Fields");
//			}

		}
	});

});