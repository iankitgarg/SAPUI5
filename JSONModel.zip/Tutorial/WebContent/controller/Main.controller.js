sap.ui.define([ "sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";
	var oName;
	var oAge;
	var oCity;
	var oGender;
	var oContact;
	return Controller.extend("tut.controller.Main", {

		init : function() {

		}
		
	});

});