sap.ui.define([ "sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";
	var oName;
	var oAge;
	var oCity;
	var oGender;
	var oContact;
	return Controller.extend("ns.controller.Main", {

		init : function() {

		},

		_CheckValues : function() {

			oName = this.getView().byId("idName").getValue();
			oAge = this.getView().byId("idAge").getValue();
			oCity = this.getView().byId("idCity").getValue();
			oGender = this.getView().byId("idGender").getValue();
			oContact = this.getView().byId("idContact").getValue();

		},

		onSubmit : function() {

			this._CheckValues();
			if (oName && oAge && oCity && oGender && oContact) {
				alert("Registration Successfull");

			} else {

				alert("Fill All required Fields");
			}

		},

		onSave : function() {
			// Check if all Input fields are filled
			this._CheckValues();
			
			//Call Fragment
			this.oFormSave = sap.ui.xmlfragment("ns.view.SaveForm", this);
			// Set Fragment as dependent on View, so that same controller can be used for both 
			this.getView().addDependent(this.oFormSave);
			
			//Take Instance of Page declared in View
			var oPage = this.getView().byId("Page1");
			
			
			//Remove all existing content of View
			oPage.removeAllContent();
			
			//Add Fragment contents to View
			oPage.addContent(this.oFormSave);
			
			//Set Input Fields values which were entered in View
			sap.ui.getCore().byId("idSaveName").setValue(oName);
			sap.ui.getCore().byId("idSaveAge").setValue(oAge);
			sap.ui.getCore().byId("idSaveCity").setValue(oCity);
			sap.ui.getCore().byId("idSaveGender").setValue(oGender);
			sap.ui.getCore().byId("idSaveContact").setValue(oContact);

		}
	});

});