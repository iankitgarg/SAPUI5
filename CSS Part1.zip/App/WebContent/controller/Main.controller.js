sap.ui.define([ "sap/ui/core/mvc/Controller"

], function(Controller) {
	"use strict";

	return Controller.extend("ns.controller.Main", {

		init : function() {

		},

		onSubmit : function() {
			var oName = this.getView().byId("idName").getValue();
			var oAge = this.getView().byId("idAge").getValue();
			var oCity = this.getView().byId("idCity").getValue();
			var oGender = this.getView().byId("idGender").getValue();
			var oContact = this.getView().byId("idContact").getValue();

			if (oName && oAge && oCity && oGender && oContact) {
				alert("Registration Successfull");

			} else {

				alert("Fill All required Fields");
			}

		}
	});

});