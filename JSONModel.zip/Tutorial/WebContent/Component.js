sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device"

], function(UIComponent, Device) {
	"use strict";

	return UIComponent.extend("tut.Component", {
		metadata : {

			version : "1.0.0",
			includes : [],
			dependencies : {
				minUI5Version : "1.38.28",
				libs : [ "sap.m", "sap.ui.layout" ]
			},

			rootView : "tut.view.Main",
			routing : {
				"config" : {
					"routerClass" : "sap.m.routing.Router",
					"viewType" : "XML",
					"viewPath" : "tut.view",
					"controlId" : "app",
					"controlAggregation" : "pages"
				},
				routes : [ {
					"pattern" : "",
					"name" : "Main",
					"target" : "Main"
				}, {
					"pattern" : "details",
					"name" : "details",
					"target" : "details"
				} ],
				targets : {
					"Main" : {
						"viewName" : "Main"
					},
					"details" : {
						"viewName" : "Details"
					}
				}
			}
		},

		init : function() {

			UIComponent.prototype.init.apply(this, arguments);
			this.getRouter().initialize();
			
			//var URL = "/sap/opu/odata/sap/ZTW_CRM_PRODUCT_SRV/"
			//Declare JSON Model
			var oModel = new sap.ui.model.json.JSONModel(URL,true);
			
			//Load Data into JSON Model from data.json file
			oModel.loadData("./model/data.json");
			
			//set this model with name JSONModel globally for this application
			this.setModel(oModel,"JSONModel");
			console.log(oModel);
			
		},

	});

});