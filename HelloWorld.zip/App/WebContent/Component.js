sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device"

], function(UIComponent, Device) {
	"use strict";

	return UIComponent.extend("ns.Component", {
		metadata : {

			version : "1.0.0",
			includes : [],
			dependencies : {
				minUI5Version : "1.38.28",
				libs : [ "sap.m", "sap.ui.layout" ]
			},
			config : {
				fullWidth : true,
				titleResources : "app.Identity",
				icon : "sap-icon://table-view",
			},
			rootView : "ns.view.Main"
		},

		init : function() {

			UIComponent.prototype.init.apply(this, arguments);
			
		},

	});

});